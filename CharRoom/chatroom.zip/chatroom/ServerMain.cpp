#include "Server.h"

// 服务端主函数
// 创建服务端对象后启动服务端
int main(int argc, char *argv[]) {
    Server server;
    server.Start();
    return 0;
}