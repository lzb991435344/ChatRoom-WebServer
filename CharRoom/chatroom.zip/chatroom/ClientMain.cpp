#include "Client.h"

// 客户端主函数
// 创建客户端对象后启动客户端
int main(int argc, char *argv[]) {
    Client client;
    client.Start();
    return 0;
}